import json
import ndex2
import networkx as nx
import pandas as pd
import mygene
from update_networks import update_networks

update_networks()